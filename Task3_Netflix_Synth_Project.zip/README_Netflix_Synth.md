# Netflix Movies SQL Project (Synthetic Dataset)

Files included:

- 01_count_by_type.csv
- 01_count_by_type.png
- 02_top_directors.csv
- 02_top_directors.png
- 03_titles_by_country.csv
- 03_titles_by_country.png
- 04_avg_movie_duration.csv
- 04_avg_movie_duration.png
- 05_recent_additions.csv
- 05_recent_additions.png
- 06_titles_per_year.csv
- 06_titles_per_year.png
- 07_long_movies_subquery.csv
- 07_long_movies_subquery.png
- 09_query_view_monthly.csv
- 09_query_view_monthly.png
- README_Netflix_Synth.md
- netflix_synth.db
- netflix_synthetic.csv
- queries_netflix_synth.sql
