-- 01_count_by_type
SELECT type, COUNT(*) AS count FROM titles GROUP BY type ORDER BY count DESC;

-- 02_top_directors
SELECT director, COUNT(*) AS title_count FROM titles WHERE director IS NOT NULL GROUP BY director ORDER BY title_count DESC LIMIT 10;

-- 03_titles_by_country
SELECT country, COUNT(*) AS count FROM titles GROUP BY country ORDER BY count DESC LIMIT 10;

-- 04_avg_movie_duration
SELECT ROUND(AVG(numeric_duration),1) AS avg_duration FROM titles WHERE type='Movie' AND numeric_duration IS NOT NULL;

-- 05_recent_additions
SELECT show_id, title, type, date_added FROM titles WHERE date_added IS NOT NULL ORDER BY date_added DESC LIMIT 20;

-- 06_titles_per_year
SELECT release_year, COUNT(*) AS count FROM titles GROUP BY release_year ORDER BY release_year DESC LIMIT 20;

-- 07_long_movies_subquery
SELECT show_id, title, duration, numeric_duration FROM titles WHERE numeric_duration > (SELECT AVG(numeric_duration) FROM titles WHERE numeric_duration IS NOT NULL) ORDER BY numeric_duration DESC LIMIT 20;

-- 08_create_view_monthly_additions
CREATE VIEW IF NOT EXISTS vw_monthly_additions AS SELECT strftime('%Y-%m', date_added) AS month, COUNT(*) AS additions FROM titles WHERE date_added IS NOT NULL GROUP BY month;

-- 09_query_view_monthly
SELECT * FROM vw_monthly_additions ORDER BY month DESC LIMIT 24;

